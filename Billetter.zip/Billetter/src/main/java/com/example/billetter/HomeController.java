package com.example.billetter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class HomeController {

    @Autowired
    private BilletterRepository rep;
    @CrossOrigin(origins = "http://localhost:63342")
    @PostMapping("/save")
    public void lagreKunde(Billeter innBillett){
        rep.lagreBilletter(innBillett);
    }
    @CrossOrigin(origins = "http://localhost:63342")
    @GetMapping("/Getfilms")
    public List<Billeter> hentAlle(){
        return rep.hentAlleBilletter();
    }
    @CrossOrigin(origins = "http://localhost:63342")
    @GetMapping("/Deleteall")
    public void slettAlle(){
        rep.slett();
    }


}