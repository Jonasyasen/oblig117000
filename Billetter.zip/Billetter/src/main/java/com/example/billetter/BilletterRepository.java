package com.example.billetter;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class  BilletterRepository {
    private List<Billeter> billeterList = new ArrayList<>();

    public void lagreBilletter(Billeter innBillett) {
        billeterList.add(innBillett);
    }

    public List<Billeter> hentAlleBilletter() {
        return billeterList;
    }

    public void slett() {
        billeterList.clear();
    }
}